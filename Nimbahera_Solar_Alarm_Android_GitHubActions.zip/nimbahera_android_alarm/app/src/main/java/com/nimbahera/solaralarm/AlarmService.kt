package com.nimbahera.solaralarm

import android.app.*
import android.content.*
import android.media.*
import android.os.*

class AlarmService: Service(){
    private var player:MediaPlayer?=null
    override fun onCreate(){super.onCreate(); createChannel(); val n=Notification.Builder(this,"solar_alarm").setSmallIcon(com.nimbahera.solaralarm.R.drawable.ic_launcher).setContentTitle("Nimbahera Solar Alarm").setContentText("Solar alarm is ringing").setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).setFullScreenIntent(PendingIntent.getActivity(this,99,Intent(this,AlarmActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE),true).setOngoing(true).build(); startForeground(9001,n); val uri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM); player=MediaPlayer.create(this,uri); player?.isLooping=true; player?.start(); Handler(Looper.getMainLooper()).postDelayed({stopSelf()},ScheduleStore(this).durationMinutes()*60000L) }
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26){val ch=NotificationChannel("solar_alarm","Solar Alarms",NotificationManager.IMPORTANCE_HIGH); ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()); ch.enableVibration(true); getSystemService(NotificationManager::class.java).createNotificationChannel(ch)} }
    override fun onStartCommand(i:Intent?,flags:Int,id:Int)=START_NOT_STICKY
    override fun onDestroy(){player?.stop();player?.release();player=null;super.onDestroy()}
    override fun onBind(i:Intent?)=null
}
