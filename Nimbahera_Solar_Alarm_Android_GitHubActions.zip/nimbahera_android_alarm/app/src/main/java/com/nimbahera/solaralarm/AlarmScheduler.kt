package com.nimbahera.solaralarm

import android.app.*
import android.content.*
import android.os.Build
import java.time.*

object AlarmScheduler {
    const val TYPE="type"; const val ID="id"; const val SUNRISE="sunrise"; const val SUNSET="sunset"
    private const val BASE=41000
    fun canExact(c:Context)=Build.VERSION.SDK_INT<31 || (c.getSystemService(AlarmManager::class.java)?.canScheduleExactAlarms()==true)
    fun scheduleAll(c:Context){ val s=ScheduleStore(c); if(!s.enabled()||!canExact(c)) return; cancelAll(c); val now=System.currentTimeMillis(); s.load().forEachIndexed { i,d -> val off=s.offsetMinutes()*60000L; if(s.sunriseEnabled()) schedule(c,BASE+i*2,d.sunrise-off,SUNRISE); if(s.sunsetEnabled()) schedule(c,BASE+i*2+1,d.sunset-off,SUNSET) } }
    private fun schedule(c:Context,id:Int,whenMs:Long,type:String){ if(whenMs<=System.currentTimeMillis()) return; val am=c.getSystemService(AlarmManager::class.java); val pi=PendingIntent.getBroadcast(c,id,Intent(c,AlarmReceiver::class.java).putExtra(TYPE,type).putExtra(ID,id),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); am.setAlarmClock(AlarmManager.AlarmClockInfo(whenMs,pi),pi) }
    fun cancelAll(c:Context){ val am=c.getSystemService(AlarmManager::class.java); for(id in BASE..BASE+500){ val pi=PendingIntent.getBroadcast(c,id,Intent(c,AlarmReceiver::class.java),PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE); if(pi!=null){am.cancel(pi);pi.cancel()} } }
}
