package com.nimbahera.solaralarm
import android.content.*

class AlarmReceiver: BroadcastReceiver(){ override fun onReceive(c:Context,i:Intent){ if(!ScheduleStore(c).enabled()) return; val type=i.getStringExtra(AlarmScheduler.TYPE)?:"alarm"; val svc=Intent(c,AlarmService::class.java).putExtra(AlarmScheduler.TYPE,type); c.startForegroundService(svc); AlarmScheduler.scheduleAll(c) } }
