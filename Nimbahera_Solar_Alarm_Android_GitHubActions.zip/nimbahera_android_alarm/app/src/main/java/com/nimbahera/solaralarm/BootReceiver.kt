package com.nimbahera.solaralarm
import android.content.*
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){AlarmScheduler.scheduleAll(c)}}
