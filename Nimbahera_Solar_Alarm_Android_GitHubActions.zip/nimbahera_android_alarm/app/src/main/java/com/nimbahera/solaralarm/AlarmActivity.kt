package com.nimbahera.solaralarm
import android.app.*
import android.os.*
import android.view.*
import android.widget.*

class AlarmActivity:Activity(){ override fun onCreate(b:Bundle?){super.onCreate(b); window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON); val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.gravity=Gravity.CENTER; l.setPadding(32,32,32,32); val t=TextView(this); t.text="☀️ Nimbahera Solar Alarm"; t.textSize=28f; val s=TextView(this); s.text="Alarm is ringing"; s.textSize=22f; val btn=Button(this); btn.text="STOP ALARM"; btn.setOnClickListener{stopService(Intent(this,AlarmService::class.java));finish()}; l.addView(t);l.addView(s);l.addView(btn);setContentView(l)} }
