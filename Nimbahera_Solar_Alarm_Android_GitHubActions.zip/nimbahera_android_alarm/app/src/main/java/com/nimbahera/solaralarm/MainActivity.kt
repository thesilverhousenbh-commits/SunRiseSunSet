package com.nimbahera.solaralarm

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.concurrent.Executors

class MainActivity:Activity(){
    private lateinit var status:TextView; private lateinit var details:TextView; private val ex=Executors.newSingleThreadExecutor(); private val lat=24.62166; private val lon=74.67999
    override fun onCreate(b:Bundle?){super.onCreate(b); buildUi(); requestNotifications(); refresh(false)}
    private fun buildUi(){val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setPadding(28,28,28,28); val title=TextView(this);title.text="Nimbahera Solar Alarm";title.textSize=28f; val sub=TextView(this);sub.text="Nimbahera, Rajasthan • PIN 312601";sub.textSize=17f; status=TextView(this);status.textSize=18f; details=TextView(this);details.textSize=17f; val en=Button(this);en.text="Enable daily alarms";en.setOnClickListener{enable()}; val dis=Button(this);dis.text="Disable";dis.setOnClickListener{ScheduleStore(this).setEnabled(false);AlarmScheduler.cancelAll(this);update()}; val rf=Button(this);rf.text="Refresh 90 days";rf.setOnClickListener{refresh(true)}; val test=Button(this);test.text="Test alarm (10 sec)";test.setOnClickListener{testAlarm()};root.addView(title);root.addView(sub);root.addView(status);root.addView(details);root.addView(en);root.addView(dis);root.addView(rf);root.addView(test);setContentView(root);update()}
    private fun requestNotifications(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),10)}
    private fun enable(){val s=ScheduleStore(this);s.setEnabled(true);if(!AlarmScheduler.canExact(this)){if(Build.VERSION.SDK_INT>=31)startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))); Toast.makeText(this,"Allow 'Alarms & reminders', then press Enable again",Toast.LENGTH_LONG).show();return}; if(s.load().size<30){refresh(true)} else {AlarmScheduler.scheduleAll(this);update()}}
    private fun refresh(show:Boolean){status.text="Loading 90 days…";ex.execute{try{val out=ArrayList<SolarDay>();val today=LocalDate.now();for(i in 0 until 90){val d=today.plusDays(i.toLong());val u="https://api.sunrise-sunset.org/json?lat=$lat&lng=$lon&date=$d&formatted=0";val c=URL(u).openConnection() as HttpURLConnection;c.connectTimeout=10000;c.readTimeout=10000;c.requestMethod="GET";val text=c.inputStream.bufferedReader().use{it.readText()};val r=JSONObject(text).getJSONObject("results");val sr=Instant.parse(r.getString("sunrise")).atZone(ZoneId.of("Asia/Kolkata")).toInstant().toEpochMilli();val ss=Instant.parse(r.getString("sunset")).atZone(ZoneId.of("Asia/Kolkata")).toInstant().toEpochMilli();out.add(SolarDay(d,sr,ss));c.disconnect()};ScheduleStore(this).save(out);runOnUiThread{status.text="90 days loaded ✓";AlarmScheduler.scheduleAll(this);update()}}catch(e:Exception){runOnUiThread{status.text="Refresh failed: ${e.message}";update()}}}}
    private fun testAlarm(){if(!AlarmScheduler.canExact(this)){Toast.makeText(this,"Allow Alarms & reminders first",Toast.LENGTH_LONG).show();return};val am=getSystemService(AlarmManager::class.java);val pi=PendingIntent.getBroadcast(this,9999,Intent(this,AlarmReceiver::class.java).putExtra(AlarmScheduler.TYPE,"test"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);am.setAlarmClock(AlarmManager.AlarmClockInfo(System.currentTimeMillis()+10000,pi),pi);Toast.makeText(this,"Test alarm scheduled for 10 seconds",Toast.LENGTH_SHORT).show()}
    private fun update(){val s=ScheduleStore(this);status.text=if(s.enabled())"Daily alarms enabled" else "Alarms OFF";val d=s.load().firstOrNull();details.text=if(d==null)"No solar data cached. Tap Refresh 90 days." else "Today: ${d.date}\nSunrise: ${fmt(d.sunrise)}  |  Alarm: ${fmt(d.sunrise-s.offsetMinutes()*60000L)}\nSunset: ${fmt(d.sunset)}  |  Alarm: ${fmt(d.sunset-s.offsetMinutes()*60000L)}\nCached days: ${s.load().size}\nOffline schedule: READY"}
    private fun fmt(ms:Long)=java.time.Instant.ofEpochMilli(ms).atZone(ZoneId.of("Asia/Kolkata")).format(DateTimeFormatter.ofPattern("hh:mm a"))
}
