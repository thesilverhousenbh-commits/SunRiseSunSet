package com.nimbahera.solaralarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class SolarDay(val date: LocalDate, val sunrise: Long, val sunset: Long)

class ScheduleStore(context: Context) {
    private val p = context.getSharedPreferences("solar", Context.MODE_PRIVATE)
    fun save(days: List<SolarDay>) { val a=JSONArray(); days.forEach { o -> a.put(JSONObject().put("date",o.date.toString()).put("sunrise",o.sunrise).put("sunset",o.sunset)) }; p.edit().putString("days",a.toString()).apply() }
    fun load(): List<SolarDay> { val s=p.getString("days",null) ?: return emptyList(); return try { val a=JSONArray(s); (0 until a.length()).map { val o=a.getJSONObject(it); SolarDay(LocalDate.parse(o.getString("date")),o.getLong("sunrise"),o.getLong("sunset")) } } catch(_:Exception){ emptyList() } }
    fun enabled()=p.getBoolean("enabled",false)
    fun setEnabled(v:Boolean)=p.edit().putBoolean("enabled",v).apply()
    fun sunriseEnabled()=p.getBoolean("sunriseEnabled",true)
    fun sunsetEnabled()=p.getBoolean("sunsetEnabled",true)
    fun setSunriseEnabled(v:Boolean)=p.edit().putBoolean("sunriseEnabled",v).apply()
    fun setSunsetEnabled(v:Boolean)=p.edit().putBoolean("sunsetEnabled",v).apply()
    fun offsetMinutes()=p.getInt("offset",15)
    fun durationMinutes()=p.getInt("duration",5)
}
