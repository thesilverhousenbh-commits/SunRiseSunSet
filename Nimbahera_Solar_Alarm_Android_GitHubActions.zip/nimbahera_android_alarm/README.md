# Nimbahera Solar Alarm

Native Android app for Nimbahera, Rajasthan (24.62166, 74.67999). It downloads 90 days of sunrise/sunset data and stores it locally. Alarms are scheduled as Android exact alarm-clock alarms 15 minutes before each event. The schedule does not require internet after data is cached.

## Build without Android Studio
1. Create a GitHub repository and upload this project.
2. Ensure GitHub Actions are enabled.
3. Run **Actions → Build Android APK → Run workflow**.
4. Open the completed workflow run and download the **Nimbahera-Solar-Alarm-debug** artifact.
5. Extract the APK and install it on Android.

## First setup on phone
- Open the app and allow notifications.
- Tap Refresh 90 days while online.
- Tap Enable daily alarms.
- Android 12+ will ask for **Alarms & reminders** exact-alarm access; allow it.
- Use Test alarm before relying on it.
- On some phones, remove battery optimization/restrictions for this app for maximum reliability.

## Notes
Sunrise/sunset times are fetched from Sunrise-Sunset.org and converted to Asia/Kolkata. Internet is not needed to trigger alarms once the local 90-day schedule is present.
